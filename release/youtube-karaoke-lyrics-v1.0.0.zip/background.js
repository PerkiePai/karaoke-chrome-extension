(function() {
  "use strict";
  const API_BASE = "https://lrclib.net/api";
  const CLIENT_HEADER = "karaoke-chrome-extension v0.1.0 (personal use)";
  const DEFAULT_RETRY_AFTER_SEC = 60;
  class LrclibRateLimitError extends Error {
    constructor(retryAfterSec) {
      super(`lrclib rate limited; retry after ${retryAfterSec}s`);
      this.retryAfterSec = retryAfterSec;
      this.name = "LrclibRateLimitError";
    }
  }
  async function searchLyrics(query, fetchImpl = fetch) {
    const url = `${API_BASE}/search?q=${encodeURIComponent(query)}`;
    const res = await fetchImpl(url, { headers: { "Lrclib-Client": CLIENT_HEADER } });
    if (res.status === 429) {
      const header = res.headers.get("retry-after");
      const parsed = header ? Number.parseInt(header, 10) : Number.NaN;
      throw new LrclibRateLimitError(
        Number.isFinite(parsed) ? parsed : DEFAULT_RETRY_AFTER_SEC
      );
    }
    if (!res.ok) {
      throw new Error(`lrclib search failed: HTTP ${res.status}`);
    }
    return await res.json();
  }
  const MATCH_THRESHOLD = 0.55;
  const MIN_TRACK_SIMILARITY = 0.35;
  const MIN_ARTIST_SIMILARITY = 0.3;
  const WEIGHT_TRACK = 0.5;
  const WEIGHT_ARTIST = 0.3;
  const WEIGHT_DURATION = 0.2;
  const VARIANT_PENALTY = 0.25;
  const SYNCED_BONUS = 0.05;
  const DURATION_TOLERANCE_SEC = 20;
  const NEUTRAL = 0.5;
  const VARIANT_WORDS = ["live", "acoustic", "cover", "remix", "instrumental", "session"];
  const VARIANT_PATTERNS = VARIANT_WORDS.map(
    (word) => [word, new RegExp(`\\b${word}\\b`, "i")]
  );
  function normalize(text) {
    return text.normalize("NFC").toLowerCase().replace(/[\s\p{P}\p{S}]+/gu, " ").trim();
  }
  function levenshtein(a, b) {
    let previous = Array.from({ length: b.length + 1 }, (_, i) => i);
    for (let i = 1; i <= a.length; i += 1) {
      const current = [i];
      for (let j = 1; j <= b.length; j += 1) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        current[j] = Math.min(
          current[j - 1] + 1,
          previous[j] + 1,
          previous[j - 1] + cost
        );
      }
      previous = current;
    }
    return previous[b.length];
  }
  function similarity(a, b) {
    const x = normalize(a);
    const y = normalize(b);
    if (!x && !y) return 1;
    if (!x || !y) return 0;
    if (x === y) return 1;
    return 1 - levenshtein(x, y) / Math.max(x.length, y.length);
  }
  function variantTags(text) {
    return new Set(
      VARIANT_PATTERNS.filter(([, pattern]) => pattern.test(text)).map(([word]) => word)
    );
  }
  function sameVariant(a, b) {
    const left = variantTags(a);
    const right = variantTags(b);
    if (left.size !== right.size) return false;
    for (const tag of left) if (!right.has(tag)) return false;
    return true;
  }
  function durationScore(wanted, candidate) {
    if (wanted === null || candidate === null) return NEUTRAL;
    const diff = Math.abs(wanted - candidate);
    return 1 - Math.min(diff / DURATION_TOLERANCE_SEC, 1);
  }
  function scoreCandidates(input, candidates) {
    return candidates.map((record) => {
      const trackSimilarity = similarity(input.track, record.trackName);
      const artistSimilarity = input.artist === null ? null : similarity(input.artist, record.artistName);
      let score = WEIGHT_TRACK * trackSimilarity + WEIGHT_ARTIST * (artistSimilarity ?? NEUTRAL) + WEIGHT_DURATION * durationScore(input.durationSec, record.duration);
      if (!sameVariant(input.track, record.trackName)) score -= VARIANT_PENALTY;
      if (record.syncedLyrics) score += SYNCED_BONUS;
      return { record, score, trackSimilarity, artistSimilarity };
    }).sort((a, b) => b.score - a.score);
  }
  function hasUsableLyrics(record) {
    if (record.instrumental) return false;
    return Boolean(record.syncedLyrics?.trim() || record.plainLyrics?.trim());
  }
  function pickBestScored(input, candidates) {
    for (const candidate of scoreCandidates(input, candidates)) {
      if (candidate.score < MATCH_THRESHOLD) return null;
      if (candidate.trackSimilarity < MIN_TRACK_SIMILARITY) continue;
      if (candidate.artistSimilarity !== null && candidate.artistSimilarity < MIN_ARTIST_SIMILARITY) {
        continue;
      }
      return candidate;
    }
    return null;
  }
  const LATIN_RUN = /[A-Za-z0-9'][A-Za-z0-9'&.\-]*/g;
  const ALL_DIGITS = /^[0-9]+$/;
  const THAI_RUN = /[฀-๿]+/g;
  const THAI_STOP_WORDS = /* @__PURE__ */ new Set([
    "เพลง",
    // "song" — e.g. "เพลง นายหญิง" → real track name is "นายหญิง"
    // "album" — e.g. a channel name "Phumin อัลบั้ม 2". Only surfaced once Thai
    // extraction became unconditional (below) instead of gated on a field
    // being >50% Thai — "Phumin อัลบั้ม 2" is exactly 50%, so this word never
    // reached extractThaiText before.
    "อัลบั้ม"
  ]);
  function isNonIdentifying(token) {
    if (ALL_DIGITS.test(token)) return true;
    const lower = token.toLowerCase();
    return VARIANT_WORDS.some((word) => word === lower);
  }
  function extractThaiText(text) {
    const runs = text.match(THAI_RUN) ?? [];
    return runs.filter((run) => !THAI_STOP_WORDS.has(run)).join(" ");
  }
  function isPredominantlyThai(text) {
    const stripped = text.replace(/\s/g, "");
    if (!stripped) return false;
    const thaiLen = (text.match(THAI_RUN) ?? []).join("").length;
    return thaiLen / stripped.length > 0.5;
  }
  const OTHER_SCRIPT_RUN = /[\p{L}\p{M}]+/gu;
  const ALL_THAI = /^[฀-๿]+$/;
  function extractOtherScriptText(text) {
    const runs = text.match(OTHER_SCRIPT_RUN) ?? [];
    return runs.filter((run) => !ALL_THAI.test(run)).join(" ");
  }
  function buildSearchQuery(artist, track) {
    const thaiParts = [];
    const otherScriptParts = [];
    const identifyingLatin = [];
    for (const field of [artist ?? "", track]) {
      const t = extractThaiText(field);
      if (t) thaiParts.push(t);
      if (isPredominantlyThai(field)) continue;
      const latin = field.match(LATIN_RUN) ?? [];
      for (const token of latin) {
        if (!isNonIdentifying(token)) identifyingLatin.push(token);
      }
      if (latin.length === 0) {
        const other = extractOtherScriptText(field);
        if (other) otherScriptParts.push(other);
      }
    }
    const foreignText = [...thaiParts, ...otherScriptParts].join(" ");
    if (identifyingLatin.length) {
      return foreignText ? `${foreignText} ${identifyingLatin.join(" ")}` : identifyingLatin.join(" ");
    }
    if (foreignText) return foreignText;
    const source = `${artist ?? ""} ${track}`;
    return source.trim().replace(/\s+/g, " ");
  }
  const VM_PREFIX = "vm:";
  const LC_PREFIX = "lc:";
  const LC_ORDER_KEY = "lc:order";
  const NF_PREFIX = "nf:";
  const NF_TTL_MS = 7 * 24 * 60 * 60 * 1e3;
  const UP_PREFIX = "up:";
  const LYRICS_CACHE_MAX = 50;
  async function isNotFoundCached(storage2, videoId) {
    const key = `${NF_PREFIX}${videoId}`;
    const result = await storage2.get([key]);
    const v = result[key];
    if (v != null && typeof v === "object" && "at" in v && typeof v.at === "number") {
      const age = Date.now() - v.at;
      if (age < NF_TTL_MS) return true;
      await storage2.remove([key]);
    }
    return false;
  }
  async function writeNotFoundCache(storage2, videoId) {
    await storage2.set({ [`${NF_PREFIX}${videoId}`]: { at: Date.now() } });
  }
  async function clearNotFoundCache(storage2, videoId) {
    await storage2.remove([`${NF_PREFIX}${videoId}`]);
  }
  async function isUserPicked(storage2, videoId) {
    const key = `${UP_PREFIX}${videoId}`;
    const result = await storage2.get([key]);
    return !!result[key];
  }
  async function writeUserPicked(storage2, videoId) {
    await storage2.set({ [`${UP_PREFIX}${videoId}`]: true });
  }
  async function readVideoMeta(storage2, videoId) {
    const key = `${VM_PREFIX}${videoId}`;
    const result = await storage2.get([key]);
    const v = result[key];
    if (v != null && typeof v === "object" && "lrclibId" in v && "offsetSec" in v) {
      return v;
    }
    return null;
  }
  async function readLyricsCache(storage2, lrclibId) {
    const key = `${LC_PREFIX}${lrclibId}`;
    const result = await storage2.get([key]);
    const v = result[key];
    return v != null ? v : null;
  }
  async function writeLyricsCache(storage2, lrclibId, record, maxEntries = LYRICS_CACHE_MAX) {
    const idStr = String(lrclibId);
    const orderResult = await storage2.get([LC_ORDER_KEY]);
    const raw = orderResult[LC_ORDER_KEY];
    const order = Array.isArray(raw) ? raw : [];
    const updated = [idStr, ...order.filter((k) => k !== idStr)];
    const writes = {
      [`${LC_PREFIX}${lrclibId}`]: record,
      [LC_ORDER_KEY]: updated.slice(0, maxEntries)
    };
    await storage2.set(writes);
    const evicted = updated.slice(maxEntries);
    if (evicted.length > 0) {
      await storage2.remove(evicted.map((k) => `${LC_PREFIX}${k}`));
    }
  }
  async function handleFetchLyrics(request, search, storage2) {
    const existingMeta = storage2 ? await readVideoMeta(storage2, request.videoId) : null;
    if (existingMeta) {
      const [cached, userPicked] = await Promise.all([
        readLyricsCache(storage2, existingMeta.lrclibId),
        isUserPicked(storage2, request.videoId)
      ]);
      if (cached) {
        if (userPicked) {
          console.log(
            `[karaoke] cache HIT (user-picked) videoId=${request.videoId} "${request.track}"`,
            `lrclibId=${existingMeta.lrclibId} offsetSec=${existingMeta.offsetSec}`
          );
          return {
            ok: true,
            record: cached,
            lrclibId: existingMeta.lrclibId,
            offsetSec: existingMeta.offsetSec,
            scrollSpeed: existingMeta.scrollSpeed ?? 1
          };
        }
        const allReadings = [
          { artist: request.artist, track: request.track },
          ...request.alternates ?? []
        ];
        let bestHitScore = 0;
        const cacheValid = allReadings.some(({ artist, track }) => {
          const hit = scoreCandidates(
            { artist, track, durationSec: request.durationSec },
            [cached]
          )[0];
          if (hit !== void 0 && hit.score > bestHitScore) bestHitScore = hit.score;
          return hit !== void 0 && hit.score >= MATCH_THRESHOLD && hit.trackSimilarity >= MIN_TRACK_SIMILARITY && (hit.artistSimilarity === null || hit.artistSimilarity >= MIN_ARTIST_SIMILARITY);
        });
        if (cacheValid) {
          console.log(
            `[karaoke] cache HIT videoId=${request.videoId} "${request.track}"`,
            `lrclibId=${existingMeta.lrclibId} score=${bestHitScore.toFixed(3)} offsetSec=${existingMeta.offsetSec}`
          );
          return {
            ok: true,
            record: cached,
            lrclibId: existingMeta.lrclibId,
            offsetSec: existingMeta.offsetSec,
            scrollSpeed: existingMeta.scrollSpeed ?? 1
          };
        }
        console.warn(
          `[karaoke] cache REJECTED videoId=${request.videoId} "${request.track}"`,
          `— cached="${cached.trackName} / ${cached.artistName}" lrclibId=${existingMeta.lrclibId}`,
          `score=${bestHitScore.toFixed(3)} < threshold=${MATCH_THRESHOLD} → re-searching`
        );
      } else {
        console.log(`[karaoke] cache MISS "${request.track}" (lrclibId=${existingMeta.lrclibId} not in lc: store) → searching`);
      }
      if (userPicked && storage2) await clearNotFoundCache(storage2, request.videoId);
    } else {
      console.log(`[karaoke] no VideoMeta for videoId=${request.videoId} → first visit, searching`);
    }
    if (storage2 && await isNotFoundCached(storage2, request.videoId)) {
      console.log(`[karaoke] not-found cache HIT videoId=${request.videoId} "${request.track}" → skipping search`);
      return { ok: false, reason: "not-found", message: "No lyrics found for this song." };
    }
    const readings = [
      { artist: request.artist, track: request.track },
      ...request.alternates ?? []
    ];
    const query = buildSearchQuery(request.artist, request.track);
    let candidates;
    try {
      candidates = await search(query);
    } catch (error) {
      if (error instanceof LrclibRateLimitError) {
        return {
          ok: false,
          reason: "rate-limited",
          message: `Rate limited by lrclib. Try again in ${error.retryAfterSec}s.`
        };
      }
      return {
        ok: false,
        reason: "network",
        message: error instanceof Error ? error.message : "Network request failed."
      };
    }
    const usable = candidates.filter(hasUsableLyrics);
    let best = null;
    for (const reading of readings) {
      const scored = pickBestScored(
        { artist: reading.artist, track: reading.track, durationSec: request.durationSec },
        usable
      );
      if (scored && (best === null || scored.score > best.score)) best = scored;
    }
    if (!best) {
      if (storage2) await writeNotFoundCache(storage2, request.videoId);
      return { ok: false, reason: "not-found", message: "No lyrics found for this song." };
    }
    const sameRecordAsBefore = existingMeta !== null && existingMeta.lrclibId === best.record.id;
    const offsetSec = sameRecordAsBefore ? existingMeta.offsetSec : 0;
    const scrollSpeed = sameRecordAsBefore ? existingMeta.scrollSpeed ?? 1 : 1;
    if (storage2) {
      await writeLyricsCache(storage2, best.record.id, best.record);
    }
    console.log(
      `[karaoke] search OK "${best.record.trackName} / ${best.record.artistName}"`,
      `lrclibId=${best.record.id} score=${best.score.toFixed(3)} offsetSec=${offsetSec} scrollSpeed=${scrollSpeed}`
    );
    return { ok: true, record: best.record, lrclibId: best.record.id, offsetSec, scrollSpeed };
  }
  const MAX_CANDIDATES = 10;
  async function handleSearchCandidates(request, search) {
    let results;
    try {
      results = await search(request.query);
    } catch (error) {
      if (error instanceof LrclibRateLimitError) {
        return {
          ok: false,
          reason: "rate-limited",
          message: `Rate limited by lrclib. Try again in ${error.retryAfterSec}s.`
        };
      }
      return {
        ok: false,
        reason: "network",
        message: error instanceof Error ? error.message : "Network request failed."
      };
    }
    return {
      ok: true,
      candidates: results.filter(hasUsableLyrics).slice(0, MAX_CANDIDATES)
    };
  }
  console.log("[karaoke] service worker started");
  const storage = {
    get: (keys) => chrome.storage.local.get(keys),
    set: (items) => chrome.storage.local.set(items),
    remove: (keys) => chrome.storage.local.remove(keys)
  };
  chrome.runtime.onInstalled.addListener(() => {
    void runSmokeTest();
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "FETCH_LYRICS") {
      void handleFetchLyrics(
        message,
        (query) => searchLyrics(query),
        storage
      ).then(sendResponse);
      return true;
    }
    if (message?.type === "SEARCH_CANDIDATES") {
      void handleSearchCandidates(
        message,
        (query) => searchLyrics(query)
      ).then(sendResponse);
      return true;
    }
    if (message?.type === "PICK_CANDIDATE") {
      const req = message;
      void Promise.all([
        writeLyricsCache(storage, req.record.id, req.record),
        clearNotFoundCache(storage, req.videoId),
        writeUserPicked(storage, req.videoId)
      ]).then(() => {
        sendResponse({ ok: true });
      });
      return true;
    }
    return false;
  });
  async function runSmokeTest() {
    try {
      const results = await searchLyrics("oasis wonderwall");
      const syncedCount = results.filter((r) => r.syncedLyrics).length;
      console.log(
        `[karaoke] SMOKE OK — ${results.length} results, ${syncedCount} with synced lyrics`
      );
    } catch (error) {
      console.error("[karaoke] SMOKE FAILED —", error);
    }
  }
})();
