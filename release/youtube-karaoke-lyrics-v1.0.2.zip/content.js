(function() {
  "use strict";
  const PANEL_STYLES = `
  :host { all: initial; }
  .kx-panel {
    font-family: "Roboto", "Noto Sans Thai", Arial, sans-serif;
    background: #0f0f0f;
    color: #f1f1f1;
    border: 1px solid #303030;
    border-radius: 12px;
    padding: 12px;
    margin-bottom: 16px;
    max-height: 60vh;
    display: flex;
    flex-direction: column;
    /* Belt-and-braces: .kx-lines has a fixed height below, so nothing should
       need to spill past this box — but if it ever does (long header/status
       text, a narrow #secondary), clip it instead of letting it render past
       the rounded border. */
    overflow: hidden;
  }
  .kx-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    border-bottom: 1px solid #303030;
    padding-bottom: 8px;
    transition: padding-bottom 0.25s ease, border-bottom-color 0.25s ease;
  }
  .kx-panel.kx-collapsed .kx-header {
    padding-bottom: 0;
    border-bottom-color: transparent;
  }
  .kx-header-main { min-width: 0; flex: 1; }
  .kx-title, .kx-header-collapsed-label { font-size: 15px; font-weight: 600; }
  .kx-subtitle { font-size: 12px; color: #aaa; margin-top: 2px; }
  .kx-header-collapsed-label {
    display: none;
    min-width: 0;
    flex: 1;
  }
  .kx-panel.kx-collapsed .kx-header-main { display: none; }
  .kx-panel.kx-collapsed .kx-header-collapsed-label { display: block; }
  /* CSS-grid accordion trick: animating a fr unit (rather than height/
     max-height) gives a smooth open/close regardless of the body's actual
     content height, with no JS measurement needed. kx-body-inner supplies
     the single grid item; its own overflow:hidden clips it as the row
     shrinks to 0fr. */
  .kx-body {
    display: grid;
    grid-template-rows: 1fr;
    opacity: 1;
    transition: grid-template-rows 0.3s ease, opacity 0.25s ease;
  }
  .kx-body-inner { overflow: hidden; min-height: 0; position: relative; }
  .kx-panel.kx-collapsed .kx-body {
    grid-template-rows: 0fr;
    opacity: 0;
  }
  .kx-collapse-btn {
    flex: none;
    width: 28px;
    height: 28px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: none;
    border: none;
    border-radius: 50%;
    color: #f1f1f1;
    fill: currentcolor;
    cursor: pointer;
    padding: 5px;
  }
  .kx-collapse-btn:hover { background: rgba(255, 255, 255, 0.1); }
  .kx-collapse-btn svg { display: block; }
  .kx-status { font-size: 12px; color: #ffb86b; padding: 8px 0; }
  .kx-retry {
    background: none;
    border: 1px solid #555;
    border-radius: 4px;
    color: #f1f1f1;
    cursor: pointer;
    font-size: 11px;
    padding: 3px 10px;
    margin: 0 0 8px;
  }
  .kx-retry:hover { background: #2a2a2a; border-color: #888; }
  .kx-lines {
    list-style: none;
    margin: 0;
    /* Fixed to roughly 5 lines' worth of height (~40px/line at the default
       15px/1.9 sizing) so the window stays compact instead of growing with
       the whole song. flex: none so the flex column never stretches or
       shrinks it. Top/bottom padding is half that height so the first/last
       lines can still be scrolled up to the vertical center — without it,
       scrollTo clamps and they're stuck off-center. */
    height: 200px;
    padding: 100px 0;
    flex: none;
    overflow-y: auto;
    font-size: 14px;
    line-height: 1.9;
    -webkit-mask-image: linear-gradient(to bottom, transparent 0%, black 15%, black 85%, transparent 100%);
    mask-image: linear-gradient(to bottom, transparent 0%, black 15%, black 85%, transparent 100%);
  }
  .kx-line {
    color: #a7a7a7;
    padding: 6px 0;
    font-size: 15px;
    font-weight: 600;
    opacity: 0.55;
    transition:
      color 0.4s cubic-bezier(0.22, 1, 0.36, 1),
      opacity 0.4s cubic-bezier(0.22, 1, 0.36, 1),
      font-size 0.4s cubic-bezier(0.22, 1, 0.36, 1);
  }
  .kx-line-active {
    color: #ffffff;
    opacity: 1;
    font-size: 20px;
  }
  .kx-line-clickable { cursor: pointer; }
  .kx-line-clickable:hover { color: #ffffff; opacity: 0.85; }
  .kx-hidden { display: none !important; }
  .kx-controls-row {
    display: flex;
    align-items: center;
    border-bottom: 1px solid #303030;
    font-size: 12px;
    color: #aaa;
  }
  .kx-offset {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 4px 0 2px;
  }
  .kx-offset button {
    background: none;
    border: 1px solid #555;
    color: #aaa;
    border-radius: 4px;
    cursor: pointer;
    padding: 1px 6px;
    font-size: 11px;
    line-height: 1.5;
  }
  .kx-offset button:hover { color: #fff; border-color: #aaa; }
  .kx-offset-value {
    min-width: 56px; width: 56px; text-align: center; font-variant-numeric: tabular-nums;
    background: none; border: none; color: inherit; font: inherit; cursor: text;
    padding: 0; border-radius: 3px;
  }
  .kx-offset-value:hover { background: #2a2a2a; }
  .kx-offset-value:focus { outline: 1px solid #555; background: #1a1a1a; cursor: text; }
  .kx-not-this {
    background: none;
    border: none;
    color: #888;
    font-size: 11px;
    cursor: pointer;
    padding: 2px 0 2px 6px;
    text-decoration: underline;
    margin-left: auto;
  }
  .kx-not-this:hover { color: #aaa; }
  .kx-search-overlay {
    position: absolute;
    top: 0; left: 0; right: 0;
    background: #0f0f0f;
    z-index: 10;
    display: flex;
    flex-direction: column;
  }
  .kx-search-form {
    display: flex;
    gap: 6px;
    padding: 4px 0 2px;
    border-bottom: 1px solid #303030;
    flex-shrink: 0;
  }
  .kx-search-input {
    flex: 1;
    background: #1a1a1a;
    border: 1px solid #555;
    border-radius: 4px;
    color: #f1f1f1;
    font-size: 12px;
    padding: 3px 6px;
    outline: none;
  }
  .kx-search-input:focus { border-color: #888; }
  .kx-search-btn {
    background: #333;
    border: 1px solid #555;
    border-radius: 4px;
    color: #f1f1f1;
    cursor: pointer;
    font-size: 11px;
    padding: 3px 8px;
  }
  .kx-search-btn:hover { background: #444; }
  .kx-search-reset {
    background: none;
    border: 1px solid #555;
    border-radius: 4px;
    color: #aaa;
    cursor: pointer;
    font-size: 11px;
    padding: 3px 8px;
  }
  .kx-search-reset:hover { color: #f1f1f1; border-color: #888; }
  .kx-search-close {
    background: none; border: none; color: #666; cursor: pointer;
    font-size: 13px; padding: 0 2px; line-height: 1;
  }
  .kx-search-close:hover { color: #aaa; }
  .kx-search-status { display: none; font-size: 12px; color: #ffb86b; padding: 6px 0; }
  .kx-candidates {
    list-style: none;
    margin: 0;
    padding: 4px 0;
    max-height: 200px;
    overflow-y: auto;
  }
  .kx-candidate {
    cursor: pointer;
    padding: 4px 0;
    display: flex;
    flex-direction: column;
    gap: 1px;
  }
  .kx-candidate:hover { background: #1a1a1a; }
  .kx-candidate-head { display: flex; align-items: center; gap: 6px; }
  .kx-candidate-title { font-size: 13px; color: #f1f1f1; }
  .kx-candidate-sub { font-size: 11px; color: #888; }
  .kx-candidate-badge {
    font-size: 9px;
    text-transform: uppercase;
    letter-spacing: 0.03em;
    padding: 1px 6px;
    border-radius: 8px;
    flex-shrink: 0;
  }
  .kx-candidate-badge-synced { background: #1b4d3e; color: #6fdcb0; }
  .kx-candidate-badge-plain { background: #4a3a1a; color: #dcb06f; }
  .kx-sync-here { margin-left: 4px; }
  .kx-speed {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 4px 0 2px;
    font-size: 12px;
    color: #aaa;
  }
  .kx-speed button {
    background: none;
    border: 1px solid #555;
    color: #aaa;
    border-radius: 4px;
    cursor: pointer;
    padding: 1px 6px;
    font-size: 11px;
    line-height: 1.5;
  }
  .kx-speed button:hover { color: #fff; border-color: #aaa; }
  .kx-speed-value { min-width: 32px; text-align: center; font-variant-numeric: tabular-nums; }
  .kx-scroll-pause { margin-left: 4px; }
`;
  const TIMESTAMP = /\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g;
  function parseLrc(lrc) {
    const lines = [];
    for (const raw of lrc.split(/\r?\n/)) {
      TIMESTAMP.lastIndex = 0;
      const timestamps = [];
      let consumed = 0;
      let match;
      while ((match = TIMESTAMP.exec(raw)) !== null) {
        if (match.index !== consumed) break;
        consumed = match.index + match[0].length;
        timestamps.push(toMs(match[1], match[2], match[3]));
      }
      if (timestamps.length === 0) continue;
      const text = raw.slice(consumed).trim();
      for (const timeMs of timestamps) lines.push({ timeMs, text });
    }
    lines.sort((a, b) => a.timeMs - b.timeMs);
    return lines;
  }
  function toMs(minutes, seconds, fraction) {
    const fractionMs = fraction ? Math.round(Number.parseFloat(`0.${fraction}`) * 1e3) : 0;
    return Number.parseInt(minutes, 10) * 6e4 + Number.parseInt(seconds, 10) * 1e3 + fractionMs;
  }
  const PANEL_HOST_ID = "karaoke-lyrics-panel-host";
  const ICON_SVG_OPEN = '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" focusable="false" aria-hidden="true" style="pointer-events: none; display: inherit; width: 100%; height: 100%;"><path d="M17.293 5.293 12 10.586 6.707 5.293a1 1 0 10-1.414 1.414L10.586 12l-5.293 5.293a1 1 0 001.414 1.414L12 13.414l5.293 5.293a1 1 0 001.414-1.414L13.414 12l5.293-5.293a1 1 0 10-1.414-1.414Z"></path></svg>';
  const ICON_SVG_COLLAPSED = '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" focusable="false" aria-hidden="true" style="pointer-events: none; display: inherit; width: 100%; height: 100%;"><path d="M12 15.05 5.4 8.45l1.4-1.4L12 12.25l5.2-5.2 1.4 1.4Z"></path></svg>';
  function mountPanel(container) {
    container.querySelector(`#${PANEL_HOST_ID}`)?.remove();
    const host = document.createElement("div");
    host.id = PANEL_HOST_ID;
    const shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = PANEL_STYLES;
    const panel2 = document.createElement("div");
    panel2.className = "kx-panel";
    panel2.innerHTML = `
    <div class="kx-header">
      <div class="kx-header-main">
        <div class="kx-title"></div>
        <div class="kx-subtitle"></div>
      </div>
      <div class="kx-header-collapsed-label">Lyrics</div>
      <button class="kx-collapse-btn" title="Minimize"></button>
    </div>
    <div class="kx-body">
      <div class="kx-body-inner">
        <div class="kx-controls-row">
          <div class="kx-offset kx-hidden">
            <button class="kx-offset-back" title="Shift lyrics earlier (−0.25 s)">◀</button>
            <input class="kx-offset-value" type="text" value="+0.00s" title="Click to type an offset (e.g. -45 or +10.5)" />
            <button class="kx-offset-fwd" title="Shift lyrics later (+0.25 s)">▶</button>
            <button class="kx-sync-here" title="Set the offset from this moment">Sync here</button>
          </div>
          <div class="kx-speed kx-hidden">
            <button class="kx-speed-down" title="Scroll slower">▼</button>
            <span class="kx-speed-value">1.0x</span>
            <button class="kx-speed-up" title="Scroll faster">▲</button>
            <button class="kx-scroll-pause" title="Pause auto-scroll">⏸</button>
          </div>
          <button class="kx-not-this kx-hidden">Not this one?</button>
        </div>
        <div class="kx-search-overlay kx-hidden">
          <form class="kx-search-form" autocomplete="off">
            <input class="kx-search-input" type="text" placeholder="Artist and song title…">
            <button type="submit" class="kx-search-btn">Search</button>
            <button type="button" class="kx-search-reset" title="Forget my correction and use the auto-detected match">Reset</button>
            <button type="button" class="kx-search-close" title="Close">✕</button>
          </form>
          <div class="kx-search-status"></div>
          <ol class="kx-candidates kx-hidden"></ol>
        </div>
        <div class="kx-status"></div>
        <button class="kx-retry kx-hidden">Retry</button>
        <ol class="kx-lines"></ol>
      </div>
    </div>
  `;
    shadow.append(style, panel2);
    container.prepend(host);
    const find = (selector) => {
      const el = panel2.querySelector(selector);
      if (!el) throw new Error(`panel element missing: ${selector}`);
      return el;
    };
    const linesEl = find(".kx-lines");
    let scrollAnimId = null;
    function animateScrollTo(target, durationMs = 350) {
      if (scrollAnimId !== null) cancelAnimationFrame(scrollAnimId);
      const start = linesEl.scrollTop;
      const delta = target - start;
      if (delta === 0) return;
      const startTime = performance.now();
      const step = (now) => {
        const t = Math.min(1, (now - startTime) / durationMs);
        const eased = 1 - Math.pow(1 - t, 3);
        linesEl.scrollTop = start + delta * eased;
        scrollAnimId = t < 1 ? requestAnimationFrame(step) : null;
      };
      scrollAnimId = requestAnimationFrame(step);
    }
    function stopScrollAnim() {
      if (scrollAnimId !== null) {
        cancelAnimationFrame(scrollAnimId);
        scrollAnimId = null;
      }
    }
    let lineClickListener = null;
    let manualScrollListener = null;
    linesEl.addEventListener(
      "wheel",
      () => {
        stopScrollAnim();
        manualScrollListener?.();
      },
      { passive: true }
    );
    linesEl.addEventListener(
      "touchmove",
      () => {
        stopScrollAnim();
        manualScrollListener?.();
      },
      { passive: true }
    );
    const collapseBtn = find(".kx-collapse-btn");
    collapseBtn.innerHTML = ICON_SVG_OPEN;
    let collapseChangeListener = null;
    function applyCollapsed(collapsed) {
      panel2.classList.toggle("kx-collapsed", collapsed);
      collapseBtn.innerHTML = collapsed ? ICON_SVG_COLLAPSED : ICON_SVG_OPEN;
      collapseBtn.title = collapsed ? "Expand" : "Minimize";
    }
    collapseBtn.addEventListener("click", () => {
      const collapsed = !panel2.classList.contains("kx-collapsed");
      applyCollapsed(collapsed);
      collapseChangeListener?.(collapsed);
    });
    let offsetNudgeListener = null;
    let offsetSetListener = null;
    const offsetInput = find(".kx-offset-value");
    offsetInput.addEventListener("focus", () => {
      offsetInput.value = offsetInput.value.replace(/s$/, "");
      offsetInput.select();
    });
    function commitOffsetInput() {
      const parsed = parseFloat(offsetInput.value);
      if (isFinite(parsed)) {
        offsetSetListener?.(parsed);
      } else {
        offsetSetListener?.(0);
      }
    }
    offsetInput.addEventListener("blur", commitOffsetInput);
    offsetInput.addEventListener("keydown", (e) => {
      e.stopPropagation();
      if (e.key === "Enter") {
        e.preventDefault();
        offsetInput.blur();
      }
      if (e.key === "Escape") {
        offsetInput.blur();
      }
    });
    find(".kx-offset-back").addEventListener("click", () => {
      offsetNudgeListener?.(-0.25);
    });
    find(".kx-offset-fwd").addEventListener("click", () => {
      offsetNudgeListener?.(0.25);
    });
    let tapSyncListener = null;
    find(".kx-sync-here").addEventListener("click", () => {
      tapSyncListener?.();
    });
    let speedNudgeListener = null;
    find(".kx-speed-down").addEventListener("click", () => {
      speedNudgeListener?.(-0.1);
    });
    find(".kx-speed-up").addEventListener("click", () => {
      speedNudgeListener?.(0.1);
    });
    let scrollPaused = false;
    let scrollPauseListener = null;
    const scrollPauseBtn = find(".kx-scroll-pause");
    scrollPauseBtn.addEventListener("click", () => {
      scrollPaused = !scrollPaused;
      scrollPauseBtn.textContent = scrollPaused ? "▶" : "⏸";
      scrollPauseListener?.(scrollPaused);
    });
    let correctRequestListener = null;
    let searchListener = null;
    let candidatePickListener = null;
    let resetMatchListener = null;
    let retryListener = null;
    find(".kx-not-this").addEventListener("click", () => {
      correctRequestListener?.();
    });
    find(".kx-search-reset").addEventListener("click", () => {
      resetMatchListener?.();
    });
    find(".kx-retry").addEventListener("click", () => {
      retryListener?.();
    });
    const searchInput = find(".kx-search-input");
    find(".kx-search-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const q = searchInput.value.trim();
      if (q) searchListener?.(q);
    });
    searchInput.addEventListener("keydown", (e) => {
      e.stopPropagation();
    });
    function isPanelTextInput(e) {
      const realTarget = e.composedPath()[0];
      return realTarget === searchInput || realTarget === offsetInput;
    }
    function swallowShortcutKey(e) {
      if (isPanelTextInput(e)) e.stopPropagation();
    }
    window.addEventListener("keydown", swallowShortcutKey, true);
    window.addEventListener("keyup", swallowShortcutKey, true);
    window.addEventListener("keypress", swallowShortcutKey, true);
    find(".kx-search-close").addEventListener("click", () => {
      find(".kx-search-overlay").classList.add("kx-hidden");
      find(".kx-candidates").classList.add("kx-hidden");
      find(".kx-search-status").textContent = "";
      find(".kx-search-status").style.display = "none";
    });
    return {
      setHeader(title, subtitle) {
        find(".kx-title").textContent = title;
        find(".kx-subtitle").textContent = subtitle;
      },
      setStatus(message) {
        const el = find(".kx-status");
        el.textContent = message;
        el.style.display = message ? "block" : "none";
      },
      setSearchStatus(message) {
        const el = find(".kx-search-status");
        el.textContent = message;
        el.style.display = message ? "block" : "none";
      },
      showRetry(visible) {
        find(".kx-retry").classList.toggle("kx-hidden", !visible);
      },
      onRetry(callback) {
        retryListener = callback;
      },
      setLines(lines, synced = true) {
        find(".kx-lines").replaceChildren(
          ...lines.map((line, index) => {
            const li = document.createElement("li");
            li.className = synced ? "kx-line kx-line-clickable" : "kx-line kx-line-active";
            li.textContent = line.text;
            if (synced) {
              li.addEventListener("click", () => lineClickListener?.(index));
            }
            return li;
          })
        );
      },
      onLineClick(callback) {
        lineClickListener = callback;
      },
      setActiveLine(index, autoScroll) {
        const items = linesEl.children;
        for (let i = 0; i < items.length; i++) {
          items[i].classList.toggle("kx-line-active", i === index);
        }
        if (index !== null && autoScroll) {
          const active = items[index];
          if (active) {
            const containerRect = linesEl.getBoundingClientRect();
            const activeRect = active.getBoundingClientRect();
            const targetScroll = linesEl.scrollTop + (activeRect.top - containerRect.top) - linesEl.clientHeight / 2 + active.clientHeight / 2;
            animateScrollTo(targetScroll);
          }
        }
      },
      onManualScroll(callback) {
        manualScrollListener = callback;
      },
      setOffsetControls(visible, offsetSec) {
        const el = find(".kx-offset");
        el.classList.toggle("kx-hidden", !visible);
        if (visible && offsetSec !== void 0) {
          const sign = offsetSec >= 0 ? "+" : "";
          offsetInput.value = `${sign}${offsetSec.toFixed(2)}s`;
        }
      },
      onOffsetNudge(callback) {
        offsetNudgeListener = callback;
      },
      onOffsetSet(callback) {
        offsetSetListener = callback;
      },
      setScrollTop(px) {
        linesEl.scrollTop = px;
      },
      getScrollTop() {
        return linesEl.scrollTop;
      },
      getScrollExtentPx() {
        return Math.max(0, linesEl.scrollHeight - linesEl.clientHeight);
      },
      setSpeedControls(visible, speed) {
        const el = find(".kx-speed");
        el.classList.toggle("kx-hidden", !visible);
        if (visible && speed !== void 0) {
          find(".kx-speed-value").textContent = `${speed.toFixed(1)}x`;
        }
        scrollPaused = false;
        scrollPauseBtn.textContent = "⏸";
      },
      onSpeedNudge(callback) {
        speedNudgeListener = callback;
      },
      onScrollPauseToggle(callback) {
        scrollPauseListener = callback;
      },
      onTapSync(callback) {
        tapSyncListener = callback;
      },
      setCollapsed(collapsed) {
        applyCollapsed(collapsed);
      },
      onCollapseChange(callback) {
        collapseChangeListener = callback;
      },
      showCorrectBar(visible) {
        find(".kx-not-this").classList.toggle("kx-hidden", !visible);
      },
      enterSearchMode(query) {
        searchInput.value = query;
        find(".kx-search-overlay").classList.remove("kx-hidden");
        find(".kx-search-form").classList.remove("kx-hidden");
        find(".kx-candidates").classList.add("kx-hidden");
      },
      showCandidates(candidates) {
        const listEl = find(".kx-candidates");
        if (candidates.length === 0) {
          listEl.classList.add("kx-hidden");
          return;
        }
        find(".kx-search-form").classList.add("kx-hidden");
        listEl.replaceChildren(
          ...candidates.map((record) => {
            const li = document.createElement("li");
            li.className = "kx-candidate";
            const head = document.createElement("div");
            head.className = "kx-candidate-head";
            const title = document.createElement("span");
            title.className = "kx-candidate-title";
            title.textContent = record.trackName;
            const synced = parseLrc(record.syncedLyrics ?? "").length > 0;
            const badge = document.createElement("span");
            badge.className = synced ? "kx-candidate-badge kx-candidate-badge-synced" : "kx-candidate-badge kx-candidate-badge-plain";
            badge.textContent = synced ? "synced" : "no timestamps";
            head.append(title, badge);
            const sub = document.createElement("span");
            sub.className = "kx-candidate-sub";
            sub.textContent = record.artistName;
            li.append(head, sub);
            li.addEventListener("click", () => candidatePickListener?.(record));
            return li;
          })
        );
        listEl.classList.remove("kx-hidden");
      },
      exitSearchMode() {
        find(".kx-search-overlay").classList.add("kx-hidden");
        find(".kx-candidates").classList.add("kx-hidden");
        find(".kx-search-status").textContent = "";
        find(".kx-search-status").style.display = "none";
      },
      onCorrectRequest(callback) {
        correctRequestListener = callback;
      },
      onSearch(callback) {
        searchListener = callback;
      },
      onCandidatePick(callback) {
        candidatePickListener = callback;
      },
      onResetMatch(callback) {
        resetMatchListener = callback;
      },
      destroy() {
        stopScrollAnim();
        window.removeEventListener("keydown", swallowShortcutKey, true);
        window.removeEventListener("keyup", swallowShortcutKey, true);
        window.removeEventListener("keypress", swallowShortcutKey, true);
        host.remove();
      }
    };
  }
  const WATCH_HOSTS = /* @__PURE__ */ new Set(["www.youtube.com", "youtube.com", "m.youtube.com"]);
  function parseVideoId(url) {
    let parsed;
    try {
      parsed = new URL(url);
    } catch {
      return null;
    }
    if (!WATCH_HOSTS.has(parsed.hostname)) return null;
    if (parsed.pathname !== "/watch") return null;
    return parsed.searchParams.get("v");
  }
  const TITLE_SELECTORS = [
    "h1.ytd-watch-metadata yt-formatted-string",
    "h1.title yt-formatted-string",
    'meta[name="title"]'
  ];
  const CHANNEL_NAME_SELECTORS = [
    "ytd-channel-name#channel-name yt-formatted-string#text",
    "#owner ytd-channel-name yt-formatted-string",
    "ytd-video-owner-renderer ytd-channel-name a"
  ];
  const WATCH_FLEXY_SELECTOR = "ytd-watch-flexy[video-id]";
  const CANONICAL_SELECTOR = 'link[rel="canonical"]';
  function detectSong(doc = document, expectedVideoId) {
    if (!pageIdentityMatches(doc, expectedVideoId)) return null;
    const rawTitle = readTitle(doc);
    if (!rawTitle) return null;
    const duration = doc.querySelector("video")?.duration;
    const durationSec = typeof duration === "number" && Number.isFinite(duration) && duration > 0 ? duration : null;
    return { rawTitle, durationSec, channelName: readChannelName(doc) };
  }
  function readPageVideoIds(doc) {
    const ids = [];
    const flexyId = doc.querySelector(WATCH_FLEXY_SELECTOR)?.getAttribute("video-id");
    if (flexyId) ids.push(flexyId);
    const canonical = doc.querySelector(CANONICAL_SELECTOR)?.getAttribute("href");
    const canonicalId = canonical ? parseVideoId(canonical) : null;
    if (canonicalId) ids.push(canonicalId);
    return ids;
  }
  function pageIdentityMatches(doc, expectedVideoId) {
    if (!expectedVideoId) return true;
    const ids = readPageVideoIds(doc);
    if (ids.length === 0) return true;
    return ids.includes(expectedVideoId);
  }
  function readTitle(doc) {
    for (const selector of TITLE_SELECTORS) {
      const el = doc.querySelector(selector);
      if (!el) continue;
      const text = el instanceof HTMLMetaElement ? el.content : el.textContent;
      if (text && text.trim()) return text.trim();
    }
    return null;
  }
  function readChannelName(doc) {
    for (const selector of CHANNEL_NAME_SELECTORS) {
      const el = doc.querySelector(selector);
      const text = el?.textContent;
      if (text && text.trim()) return text.trim();
    }
    return null;
  }
  function decideReconcile(input) {
    const { urlVideoId, currentVideoId: currentVideoId2, detectedTitle, renderedTitle: renderedTitle2, hasPanel, isLoading: isLoading2 } = input;
    if (urlVideoId !== currentVideoId2) {
      return urlVideoId === null ? { kind: "clear" } : { kind: "activate", videoId: urlVideoId };
    }
    if (urlVideoId === null) return { kind: "idle" };
    if (!hasPanel || isLoading2) return { kind: "idle" };
    if (detectedTitle === null) return { kind: "idle" };
    if (detectedTitle === renderedTitle2) return { kind: "idle" };
    return { kind: "reload", videoId: urlVideoId };
  }
  function planRender(record) {
    const syncedLines = parseLrc(record.syncedLyrics ?? "");
    if (syncedLines.length > 0) {
      return { status: "", lines: syncedLines, synced: true };
    }
    if (record.plainLyrics?.trim()) {
      return {
        status: "No timings available for this track.",
        lines: record.plainLyrics.split(/\r?\n/).map((text, index) => ({ timeMs: index, text })),
        synced: false
      };
    }
    return {
      status: record.instrumental ? "This track is marked instrumental." : "No lyrics available for this track.",
      lines: [],
      synced: false
    };
  }
  const SCROLL_SUSPEND_MS = 3e3;
  function createSyncEngineState() {
    return { activeIndex: null, lastManualScrollAtMs: null };
  }
  function findActiveLineIndex(lines, currentTimeMs) {
    if (lines.length === 0 || currentTimeMs < lines[0].timeMs) return null;
    let lo = 0;
    let hi = lines.length - 1;
    while (lo < hi) {
      const mid = Math.ceil((lo + hi) / 2);
      if (lines[mid].timeMs <= currentTimeMs) lo = mid;
      else hi = mid - 1;
    }
    while (lo >= 0 && lines[lo].text === "") lo -= 1;
    return lo < 0 ? null : lo;
  }
  function isScrollSuspended(lastManualScrollAtMs, nowMs) {
    return lastManualScrollAtMs !== null && nowMs - lastManualScrollAtMs < SCROLL_SUSPEND_MS;
  }
  function tick(state, lines, currentTimeMs, nowMs) {
    const index = findActiveLineIndex(lines, currentTimeMs);
    if (index === state.activeIndex) return null;
    state.activeIndex = index;
    return { index, autoScroll: !isScrollSuspended(state.lastManualScrollAtMs, nowMs) };
  }
  function notifyManualScroll(state, nowMs) {
    state.lastManualScrollAtMs = nowMs;
  }
  function startSyncLoop(video, panel2, lines, initialOffsetMs = 0) {
    const state = createSyncEngineState();
    let offsetMs = initialOffsetMs;
    let rafId = null;
    function apply() {
      const result = tick(state, lines, video.currentTime * 1e3 + offsetMs, Date.now());
      if (result) panel2.setActiveLine(result.index, result.autoScroll);
    }
    function frame() {
      apply();
      rafId = requestAnimationFrame(frame);
    }
    function handlePlay() {
      if (rafId === null) rafId = requestAnimationFrame(frame);
    }
    function handlePause() {
      if (rafId !== null) {
        cancelAnimationFrame(rafId);
        rafId = null;
      }
    }
    function handleManualScroll() {
      notifyManualScroll(state, Date.now());
    }
    video.addEventListener("play", handlePlay);
    video.addEventListener("pause", handlePause);
    video.addEventListener("seeked", apply);
    panel2.onManualScroll(handleManualScroll);
    apply();
    if (!video.paused) handlePlay();
    return {
      stop() {
        handlePause();
        video.removeEventListener("play", handlePlay);
        video.removeEventListener("pause", handlePause);
        video.removeEventListener("seeked", apply);
        panel2.onManualScroll(() => {
        });
      },
      setOffsetMs(ms) {
        offsetMs = ms;
        apply();
      },
      centerLine(index) {
        state.lastManualScrollAtMs = null;
        state.activeIndex = index;
        panel2.setActiveLine(index, true);
      }
    };
  }
  function computeAutoScrollTopPx(currentTimeMs, durationMs, extentPx, speed) {
    if (durationMs <= 0 || extentPx <= 0) return 0;
    const progress = currentTimeMs / durationMs * speed;
    return Math.max(0, Math.min(1, progress)) * extentPx;
  }
  function advanceAutoScrollTopPx(currentTopPx, deltaMs, durationMs, extentPx, speed) {
    if (durationMs <= 0 || extentPx <= 0) return 0;
    const deltaPx = deltaMs / durationMs * speed * extentPx;
    return Math.max(0, Math.min(extentPx, currentTopPx + deltaPx));
  }
  const MANUAL_SCROLL_EPSILON_PX = 1;
  const EDGE_PAD_SEC = 5;
  function startAutoScrollLoop(video, panel2, durationSec, initialSpeed = 1) {
    let speed = initialSpeed;
    let paused = false;
    let rafId = null;
    let lastVideoMs = video.currentTime * 1e3;
    const durationMs = durationSec * 1e3;
    const edgePadMs = Math.min(EDGE_PAD_SEC * 1e3, durationMs / 4);
    const effectiveDurationMs = durationMs - edgePadMs * 2;
    function effectiveMs(rawMs) {
      return Math.max(0, Math.min(effectiveDurationMs, rawMs - edgePadMs));
    }
    let posPx = 0;
    let lastWrittenPx = 0;
    function writeScrollTop(px) {
      posPx = px;
      lastWrittenPx = px;
      panel2.setScrollTop(px);
    }
    function snapToVideoTime() {
      const extentPx = panel2.getScrollExtentPx();
      writeScrollTop(computeAutoScrollTopPx(effectiveMs(video.currentTime * 1e3), effectiveDurationMs, extentPx, speed));
      lastVideoMs = video.currentTime * 1e3;
    }
    function advance() {
      const domTop = panel2.getScrollTop();
      if (Math.abs(domTop - lastWrittenPx) > MANUAL_SCROLL_EPSILON_PX) {
        posPx = domTop;
        lastWrittenPx = domTop;
      }
      const nowMs = video.currentTime * 1e3;
      const deltaEffMs = effectiveMs(nowMs) - effectiveMs(lastVideoMs);
      lastVideoMs = nowMs;
      if (paused) return;
      const extentPx = panel2.getScrollExtentPx();
      writeScrollTop(advanceAutoScrollTopPx(posPx, deltaEffMs, effectiveDurationMs, extentPx, speed));
    }
    function frame() {
      advance();
      rafId = requestAnimationFrame(frame);
    }
    function handlePlay() {
      if (rafId === null) rafId = requestAnimationFrame(frame);
    }
    function handlePause() {
      if (rafId !== null) {
        cancelAnimationFrame(rafId);
        rafId = null;
      }
    }
    function handlePauseToggle(newPaused) {
      paused = newPaused;
    }
    video.addEventListener("play", handlePlay);
    video.addEventListener("pause", handlePause);
    video.addEventListener("seeked", snapToVideoTime);
    panel2.onScrollPauseToggle(handlePauseToggle);
    snapToVideoTime();
    if (!video.paused) handlePlay();
    return {
      stop() {
        handlePause();
        video.removeEventListener("play", handlePlay);
        video.removeEventListener("pause", handlePause);
        video.removeEventListener("seeked", snapToVideoTime);
        panel2.onScrollPauseToggle(() => {
        });
      },
      setSpeed(newSpeed) {
        speed = newSpeed;
      }
    };
  }
  const YT_INITIAL_DATA_PATTERN = /var ytInitialData\s*=\s*(\{.*?\});/s;
  const YT_INITIAL_PLAYER_RESPONSE_PATTERN$1 = /var ytInitialPlayerResponse\s*=\s*(\{.*?\});/s;
  const ART_TRACK_PATTERN = /^Provided to YouTube by .+?\n\n(.+?) · (.+?)\n/m;
  const STRUCTURED_DESCRIPTION_PANEL_ID = "engagement-panel-structured-description";
  function parseMusicAttribution(html) {
    const match = html.match(YT_INITIAL_DATA_PATTERN);
    if (!match) return null;
    let data;
    try {
      data = JSON.parse(match[1]);
    } catch {
      return null;
    }
    const vm = findVideoAttributeViewModel(data);
    if (!vm) return null;
    const title = typeof vm.title === "string" ? vm.title : null;
    const artist = typeof vm.subtitle === "string" ? vm.subtitle : null;
    if (!title || !artist) return null;
    const secondary = vm.secondarySubtitle;
    const album = typeof secondary === "object" && secondary !== null && "content" in secondary && typeof secondary.content === "string" ? secondary.content : null;
    return { title, artist, album };
  }
  function parseArtTrackDescription(html) {
    const match = html.match(YT_INITIAL_PLAYER_RESPONSE_PATTERN$1);
    if (!match) return null;
    let data;
    try {
      data = JSON.parse(match[1]);
    } catch {
      return null;
    }
    if (typeof data !== "object" || data === null) return null;
    const videoDetails = data["videoDetails"];
    if (typeof videoDetails !== "object" || videoDetails === null) return null;
    const desc = videoDetails["shortDescription"];
    if (typeof desc !== "string") return null;
    const artMatch = desc.match(ART_TRACK_PATTERN);
    if (!artMatch) return null;
    const title = artMatch[1]?.trim();
    const artist = artMatch[2]?.trim();
    if (!title || !artist) return null;
    return { title, artist };
  }
  function findVideoAttributeViewModel(data) {
    if (typeof data !== "object" || data === null) return null;
    const panels = data["engagementPanels"];
    if (!Array.isArray(panels)) return null;
    for (const panel2 of panels) {
      const renderer = panel2?.engagementPanelSectionListRenderer;
      if (renderer?.panelIdentifier !== STRUCTURED_DESCRIPTION_PANEL_ID) continue;
      const items = renderer?.content?.structuredDescriptionContentRenderer?.items;
      if (!Array.isArray(items)) continue;
      for (const item of items) {
        const cards = item?.horizontalCardListRenderer?.cards;
        if (!Array.isArray(cards)) continue;
        for (const card of cards) {
          const vm = card?.videoAttributeViewModel;
          if (vm && typeof vm === "object") return vm;
        }
      }
    }
    return null;
  }
  const YT_INITIAL_PLAYER_RESPONSE_PATTERN = /var ytInitialPlayerResponse\s*=\s*(\{.*?\});/s;
  const MUSIC_KEYWORDS = /* @__PURE__ */ new Set([
    "music",
    "song",
    "lyrics",
    "mv",
    "ost",
    "soundtrack",
    "official audio"
  ]);
  function parseMusicSignals(html) {
    const match = html.match(YT_INITIAL_PLAYER_RESPONSE_PATTERN);
    if (!match) return { hasCopyrightNotice: false, hasMusicKeyword: false };
    let data;
    try {
      data = JSON.parse(match[1]);
    } catch {
      return { hasCopyrightNotice: false, hasMusicKeyword: false };
    }
    if (typeof data !== "object" || data === null) return { hasCopyrightNotice: false, hasMusicKeyword: false };
    const videoDetails = data["videoDetails"];
    if (typeof videoDetails !== "object" || videoDetails === null) return { hasCopyrightNotice: false, hasMusicKeyword: false };
    const vd = videoDetails;
    const desc = vd["shortDescription"];
    const hasCopyrightNotice = typeof desc === "string" && desc.includes("℗");
    const keywords = vd["keywords"];
    const hasMusicKeyword = Array.isArray(keywords) && keywords.some(
      (k) => typeof k === "string" && MUSIC_KEYWORDS.has(k.toLowerCase())
    );
    return { hasCopyrightNotice, hasMusicKeyword };
  }
  const NON_MUSIC_CATEGORIES = /* @__PURE__ */ new Set([
    "Gaming",
    "Sports",
    "News & Politics",
    "Howto & Style",
    "Science & Technology",
    "Autos & Vehicles",
    "Travel & Events",
    "Pets & Animals",
    "Education",
    "Nonprofits & Activism"
  ]);
  function parseVideoCategory(html) {
    const match = html.match(YT_INITIAL_PLAYER_RESPONSE_PATTERN);
    if (!match) return null;
    let data;
    try {
      data = JSON.parse(match[1]);
    } catch {
      return null;
    }
    if (typeof data !== "object" || data === null) return null;
    const microformat = data["microformat"];
    if (typeof microformat !== "object" || microformat === null) return null;
    const renderer = microformat["playerMicroformatRenderer"];
    if (typeof renderer !== "object" || renderer === null) return null;
    const category = renderer["category"];
    return typeof category === "string" ? category : null;
  }
  function isConfidentlyNonMusic(category) {
    return category !== null && NON_MUSIC_CATEGORIES.has(category);
  }
  const FETCH_TIMEOUT_MS = 5e3;
  async function fetchVideoPageSignals(videoId, fetchImpl = fetch) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    try {
      const response = await fetchImpl(`https://www.youtube.com/watch?v=${videoId}`, {
        signal: controller.signal
      });
      if (!response.ok) return { attribution: null, artTrack: null, category: null, hasCopyrightNotice: false, hasMusicKeyword: false };
      const html = await response.text();
      const { hasCopyrightNotice, hasMusicKeyword } = parseMusicSignals(html);
      return {
        attribution: parseMusicAttribution(html),
        artTrack: parseArtTrackDescription(html),
        category: parseVideoCategory(html),
        hasCopyrightNotice,
        hasMusicKeyword
      };
    } catch {
      return { attribution: null, artTrack: null, category: null, hasCopyrightNotice: false, hasMusicKeyword: false };
    } finally {
      clearTimeout(timeout);
    }
  }
  const DUPLICATED_ACROSS_BRACKETS = /(\S+(?:\s+\S+){0,3})(\s*(?:【[^】]*】|「[^」]*」|\[[^\]]*\]|\([^)]*\)|（[^）]*）))\s*\1\s*$/i;
  const PROMO_KEYWORDS_SRC = "(?:official|lyrics?|audio|m\\/?v|visualizer|teaser|hd|4k|\\d{3,4}p)";
  const BRACKETED_NOISE = new RegExp(
    `[([（]\\s*[^)\\]）]*\\b${PROMO_KEYWORDS_SRC}\\b[^)\\]）]*\\s*[)\\]）]`,
    "gi"
  );
  const CJK_BRACKETED_NOISE = new RegExp(
    `(?:【[^】]*\\b${PROMO_KEYWORDS_SRC}\\b[^】]*】|「[^」]*\\b${PROMO_KEYWORDS_SRC}\\b[^」]*」)`,
    "gi"
  );
  const FEATURED_BRACKETED = /\s*[([（]\s*\b(?:featuring|feat\.?|ft\.?)\s*[^)\]）]*[)\]）]/gi;
  const FEATURED_BARE = /\s*\b(?:featuring|feat\.?|ft\.?)\s+.*?(?=\s+[-–—|]\s|$)/gi;
  const BARE_NOISE = [
    // Trailing pipe suffixes, restricted to known promo words: a pipe can also
    // appear legitimately in a title, so this must never strip every suffix.
    /\|\s*(?:official|lyrics?|audio|m\/?v|visualizer|teaser)\b[^|]*$/gi,
    /\bofficial\s+(?:music\s+)?video\b/gi,
    /\bofficial\s+(?:audio|mv)\b/gi,
    /(?:\s+\b(?:hd|4k|1080p|720p)\b)+\s*$/gi,
    // Language-version qualifiers after a separator — e.g. "Love To Death - English".
    // A single language word at the tail carries no identifying information and
    // poisons lrclib queries (q=… English → 0 results).
    /\s*[-–—|]\s*(?:english|thai|japanese|korean|chinese|spanish|french|german|portuguese|italian|arabic|hindi)\s*$/gi
  ];
  const SEPARATORS = [" - ", " – ", " — ", " | ", " /", "/ "];
  const EDGE_JUNK = /^[-–—|:\s]+|[-–—|:\s]+$/g;
  function normalizeTitle(rawTitle) {
    let text = rawTitle.normalize("NFC");
    text = text.replace(DUPLICATED_ACROSS_BRACKETS, "$1$2");
    text = text.replace(CJK_BRACKETED_NOISE, " ");
    text = text.replace(BRACKETED_NOISE, " ");
    text = text.replace(FEATURED_BRACKETED, " ");
    text = text.replace(FEATURED_BARE, " ");
    for (const pattern of BARE_NOISE) text = text.replace(pattern, " ");
    text = text.replace(/\s+/g, " ").trim().replace(EDGE_JUNK, "").trim();
    const candidates = SEPARATORS.map((separator) => ({
      separator,
      // index > 0 so a leading separator never yields an empty artist.
      index: text.indexOf(separator)
    })).filter(({ index }) => index > 0).sort((a, b) => a.index - b.index);
    for (const { separator, index } of candidates) {
      const artist = text.slice(0, index).trim();
      const track = text.slice(index + separator.length).trim();
      if (artist && track) return { artist, track };
    }
    return { artist: null, track: text };
  }
  function normalizeTitleCandidates(rawTitle) {
    const primary = normalizeTitle(rawTitle);
    if (primary.artist === null) return [primary];
    return [primary, { artist: primary.track, track: primary.artist }];
  }
  const SECONDARY_SELECTOR = "ytd-watch-flexy #secondary";
  const SECONDARY_POLL_MS = 200;
  const SECONDARY_TIMEOUT_MS = 1e4;
  const NAVIGATION_POLL_MS = 1e3;
  const TITLE_TIMEOUT_MS = 1e4;
  function clampOffset(sec) {
    const video = document.querySelector("video");
    const dur = video && isFinite(video.duration) ? video.duration : Infinity;
    return Math.max(-dur, Math.min(dur, sec));
  }
  const SPEED_MIN = 0.3;
  const SPEED_MAX = 3;
  let panel = null;
  let panelCollapsed = false;
  let currentVideoId = null;
  let renderedTitle = null;
  let isLoading = false;
  let generation = 0;
  let currentLrclibId = null;
  let currentRecord = null;
  let currentOffsetSec = 0;
  let currentSyncedLines = [];
  let currentScrollSpeed = 1;
  let currentDurationSec = null;
  let currentSyncLoop = null;
  let currentAutoScrollLoop = null;
  let disposers = [];
  function addDisposer(dispose) {
    disposers.push(dispose);
  }
  function disposeAll() {
    for (const dispose of disposers) dispose();
    disposers = [];
  }
  function persistVideoMeta(videoId, lrclibId, reason) {
    console.log(
      `[karaoke] vm:write (${reason}) videoId=${videoId} lrclibId=${lrclibId}`,
      `offsetSec=${currentOffsetSec} scrollSpeed=${currentScrollSpeed}`
    );
    void chrome.storage.local.set({
      [`vm:${videoId}`]: { lrclibId, offsetSec: currentOffsetSec, scrollSpeed: currentScrollSpeed }
    });
  }
  const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  function teardown() {
    disposeAll();
    panel?.destroy();
    panel = null;
    renderedTitle = null;
    currentLrclibId = null;
    currentRecord = null;
    currentOffsetSec = 0;
    currentSyncedLines = [];
    currentScrollSpeed = 1;
    currentDurationSec = null;
    currentSyncLoop = null;
    currentAutoScrollLoop = null;
    isLoading = false;
    generation += 1;
  }
  async function waitForSecondary() {
    const deadline = Date.now() + SECONDARY_TIMEOUT_MS;
    while (Date.now() < deadline) {
      const el = document.querySelector(SECONDARY_SELECTOR);
      if (el && el.offsetParent !== null) return el;
      await delay(SECONDARY_POLL_MS);
    }
    return null;
  }
  async function waitForSong(videoId) {
    const deadline = Date.now() + TITLE_TIMEOUT_MS;
    let candidate = null;
    let withoutDuration = null;
    while (Date.now() < deadline) {
      const song = detectSong(document, videoId);
      if (song) {
        if (song.durationSec !== null) {
          if (candidate !== null && candidate.rawTitle === song.rawTitle) {
            return song;
          }
          candidate = song;
        } else {
          withoutDuration = song;
          candidate = null;
        }
      } else {
        candidate = null;
      }
      await delay(SECONDARY_POLL_MS);
    }
    return withoutDuration;
  }
  async function activate(videoId) {
    const gen = generation;
    const container = await waitForSecondary();
    if (!container || gen !== generation) return;
    panel = mountPanel(container);
    panel.setHeader("Karaoke Lyrics", "identifying song…");
    panel.setStatus("Looking up lyrics…");
    panel.setCollapsed(panelCollapsed);
    panel.onCollapseChange((collapsed) => {
      panelCollapsed = collapsed;
    });
    panel.onOffsetNudge((delta) => {
      currentOffsetSec = clampOffset(currentOffsetSec + delta);
      currentSyncLoop?.setOffsetMs(currentOffsetSec * 1e3);
      panel?.setOffsetControls(true, currentOffsetSec);
      if (currentVideoId !== null && currentLrclibId !== null) {
        persistVideoMeta(currentVideoId, currentLrclibId, "nudge");
      }
    });
    panel.onOffsetSet((sec) => {
      currentOffsetSec = clampOffset(sec);
      currentSyncLoop?.setOffsetMs(currentOffsetSec * 1e3);
      panel?.setOffsetControls(true, currentOffsetSec);
      if (currentVideoId !== null && currentLrclibId !== null) {
        persistVideoMeta(currentVideoId, currentLrclibId, "nudge");
      }
    });
    panel.onTapSync(() => {
      const video = document.querySelector("video");
      const firstLine = currentSyncedLines.find((line) => line.text !== "");
      if (!video || !firstLine) return;
      const firstLineMs = firstLine.timeMs;
      currentOffsetSec = (firstLineMs - video.currentTime * 1e3) / 1e3;
      currentOffsetSec = clampOffset(currentOffsetSec);
      currentSyncLoop?.setOffsetMs(currentOffsetSec * 1e3);
      panel?.setOffsetControls(true, currentOffsetSec);
      if (currentVideoId !== null && currentLrclibId !== null) {
        persistVideoMeta(currentVideoId, currentLrclibId, "tap-sync");
      }
    });
    panel.onLineClick((index) => {
      const line = currentSyncedLines[index];
      if (!line) return;
      const video = document.querySelector("video");
      if (video) video.currentTime = Math.max(0, line.timeMs / 1e3 - currentOffsetSec);
      currentSyncLoop?.centerLine(index);
    });
    panel.onSpeedNudge((delta) => {
      currentScrollSpeed = Math.max(SPEED_MIN, Math.min(SPEED_MAX, currentScrollSpeed + delta));
      currentAutoScrollLoop?.setSpeed(currentScrollSpeed);
      panel?.setSpeedControls(true, currentScrollSpeed);
      if (currentVideoId !== null && currentLrclibId !== null) {
        persistVideoMeta(currentVideoId, currentLrclibId, "speed-nudge");
      }
    });
    panel.onCorrectRequest(() => {
      const prefilledQuery = currentRecord !== null ? [currentRecord.trackName, currentRecord.artistName].filter(Boolean).join(" ") : "";
      panel.enterSearchMode(prefilledQuery);
    });
    let searchInFlight = false;
    panel.onSearch(async (query) => {
      if (searchInFlight) return;
      searchInFlight = true;
      const searchGen = generation;
      panel.setSearchStatus("Searching…");
      try {
        let resp;
        try {
          resp = await chrome.runtime.sendMessage({
            type: "SEARCH_CANDIDATES",
            query
          });
        } catch {
          if (searchGen !== generation || !panel) return;
          panel.setSearchStatus("Search failed. Is the extension worker running?");
          return;
        }
        if (searchGen !== generation || !panel) return;
        if (!resp.ok) {
          panel.setSearchStatus(resp.message);
          return;
        }
        if (resp.candidates.length === 0) {
          panel.setSearchStatus("No results found. Try different keywords.");
          return;
        }
        panel.setSearchStatus("");
        panel.showCandidates(resp.candidates);
      } finally {
        searchInFlight = false;
      }
    });
    panel.onCandidatePick((record) => {
      panel.exitSearchMode();
      panel.setHeader(record.trackName, record.artistName);
      const plan = planRender(record);
      disposeAll();
      panel.setStatus(plan.status);
      panel.setLines(plan.lines, plan.synced);
      currentLrclibId = record.id;
      currentRecord = record;
      currentOffsetSec = 0;
      currentScrollSpeed = 1;
      if (currentVideoId !== null) {
        persistVideoMeta(currentVideoId, record.id, "pick");
      }
      if (plan.synced) {
        currentSyncedLines = plan.lines;
        panel.setOffsetControls(true, 0);
        panel.setSpeedControls(false);
        const video = document.querySelector("video");
        if (video) {
          const loop = startSyncLoop(video, panel, plan.lines, 0);
          currentSyncLoop = loop;
          addDisposer(() => {
            loop.stop();
            currentSyncLoop = null;
          });
        }
      } else {
        currentSyncedLines = [];
        panel.setOffsetControls(false);
        const video = document.querySelector("video");
        if (video && plan.lines.length > 0 && currentDurationSec !== null && currentDurationSec > 0) {
          panel.setSpeedControls(true, currentScrollSpeed);
          const loop = startAutoScrollLoop(video, panel, currentDurationSec, currentScrollSpeed);
          currentAutoScrollLoop = loop;
          addDisposer(() => {
            loop.stop();
            currentAutoScrollLoop = null;
          });
        } else {
          panel.setSpeedControls(false);
        }
      }
      if (currentVideoId !== null) {
        void chrome.runtime.sendMessage({
          type: "PICK_CANDIDATE",
          videoId: currentVideoId,
          record
        });
      }
    });
    panel.onRetry(() => {
      const videoId2 = currentVideoId;
      if (videoId2 === null) return;
      panel.showRetry(false);
      generation += 1;
      const freshGen = generation;
      void load(videoId2, freshGen).catch((error) => {
        console.error("[karaoke] retry load failed", error);
      });
    });
    panel.onResetMatch(() => {
      const videoId2 = currentVideoId;
      if (videoId2 === null) return;
      panel.exitSearchMode();
      void chrome.runtime.sendMessage({ type: "RESET_MATCH", videoId: videoId2 }).then(() => {
        if (videoId2 !== currentVideoId) return;
        currentLrclibId = null;
        generation += 1;
        const freshGen = generation;
        void load(videoId2, freshGen).catch((error) => {
          console.error("[karaoke] reset-match reload failed", error);
        });
      });
    });
    await load(videoId, gen);
  }
  async function load(videoId, gen) {
    isLoading = true;
    try {
      const [song, { attribution, artTrack, category, hasCopyrightNotice, hasMusicKeyword }] = await Promise.all([
        waitForSong(videoId),
        fetchVideoPageSignals(videoId)
      ]);
      if (gen !== generation || !panel) return;
      if (!song) {
        panel.setStatus("Could not read the video title.");
        return;
      }
      renderedTitle = song.rawTitle;
      currentDurationSec = song.durationSec;
      const titleReadings = normalizeTitleCandidates(song.rawTitle);
      if (titleReadings[0].artist === null && song.channelName) {
        console.log(`[karaoke] using channel-name fallback artist: "${song.channelName}"`);
        titleReadings.push({ artist: song.channelName, track: titleReadings[0].track });
      }
      if (attribution) {
        console.log(`[karaoke] using Music attribution: "${attribution.title}" / "${attribution.artist}"`);
      }
      if (artTrack) {
        console.log(`[karaoke] using Art Track description: "${artTrack.title}" / "${artTrack.artist}"`);
      }
      const extraReadings = [
        ...attribution ? [{ artist: attribution.artist, track: attribution.title }] : [],
        ...artTrack ? [{ artist: artTrack.artist, track: artTrack.title }] : []
      ];
      const readings = extraReadings.length > 0 ? [...extraReadings, ...titleReadings] : titleReadings;
      const primary = readings[0];
      panel.setHeader(primary.track, primary.artist ?? "unknown artist");
      const skipSearchIfNonMusic = !attribution && !artTrack && !hasCopyrightNotice && !hasMusicKeyword && isConfidentlyNonMusic(category);
      if (skipSearchIfNonMusic) {
        console.log(`[karaoke] category gate: "${song.rawTitle}" is category=${category}`);
      }
      const request = {
        type: "FETCH_LYRICS",
        videoId,
        artist: primary.artist,
        track: primary.track,
        durationSec: song.durationSec,
        alternates: readings.slice(1),
        skipSearchIfNonMusic
      };
      let response;
      try {
        response = await chrome.runtime.sendMessage(request);
      } catch (error) {
        console.error("[karaoke] message failed", error);
        if (gen === generation && panel) {
          panel.setStatus("Extension worker unavailable. Reload the page.");
        }
        return;
      }
      if (gen !== generation || !panel) return;
      if (!response.ok) {
        console.warn(`[karaoke] load failed for "${song.rawTitle}": ${response.reason} — ${response.message}`);
        disposeAll();
        panel.setStatus(response.message);
        panel.setLines([]);
        panel.setOffsetControls(false);
        panel.setSpeedControls(false);
        currentSyncedLines = [];
        if (response.reason === "not-found" || response.reason === "category-gated") panel.showCorrectBar(true);
        panel.showRetry(response.reason === "network" || response.reason === "rate-limited");
        return;
      }
      console.log(
        `[karaoke] load OK "${response.record.trackName} / ${response.record.artistName}"`,
        `lrclibId=${response.lrclibId} offsetSec=${response.offsetSec} scrollSpeed=${response.scrollSpeed}`,
        `durationSec=${song.durationSec ?? "null"}`
      );
      const { record } = response;
      if (currentLrclibId === null) {
        currentOffsetSec = response.offsetSec;
        currentScrollSpeed = response.scrollSpeed;
      }
      currentLrclibId = response.lrclibId;
      persistVideoMeta(videoId, response.lrclibId, "load");
      currentRecord = response.record;
      panel.setHeader(record.trackName, record.artistName);
      panel.showCorrectBar(true);
      panel.showRetry(false);
      const plan = planRender(record);
      disposeAll();
      panel.setStatus(plan.status);
      panel.setLines(plan.lines, plan.synced);
      if (plan.synced) {
        currentSyncedLines = plan.lines;
        panel.setSpeedControls(false);
        const video = document.querySelector("video");
        if (video) {
          const syncLoop = startSyncLoop(video, panel, plan.lines, currentOffsetSec * 1e3);
          currentSyncLoop = syncLoop;
          addDisposer(() => {
            syncLoop.stop();
            currentSyncLoop = null;
          });
          panel.setOffsetControls(true, currentOffsetSec);
        } else {
          panel.setOffsetControls(false);
        }
      } else {
        currentSyncedLines = [];
        panel.setOffsetControls(false);
        const video = document.querySelector("video");
        if (video && plan.lines.length > 0 && song.durationSec !== null && song.durationSec > 0) {
          panel.setSpeedControls(true, currentScrollSpeed);
          const loop = startAutoScrollLoop(video, panel, song.durationSec, currentScrollSpeed);
          currentAutoScrollLoop = loop;
          addDisposer(() => {
            loop.stop();
            currentAutoScrollLoop = null;
          });
        } else {
          panel.setSpeedControls(false);
        }
      }
    } finally {
      if (gen === generation) isLoading = false;
    }
  }
  function reconcile() {
    if (panel !== null && document.querySelector(`#${PANEL_HOST_ID}`) === null) {
      teardown();
      currentVideoId = null;
    }
    const urlVideoId = parseVideoId(location.href);
    const detectedTitle = urlVideoId ? detectSong(document, urlVideoId)?.rawTitle ?? null : null;
    const action = decideReconcile({
      urlVideoId,
      currentVideoId,
      detectedTitle,
      renderedTitle,
      hasPanel: panel !== null,
      isLoading
    });
    switch (action.kind) {
      case "idle":
        return;
      case "clear":
        currentVideoId = null;
        teardown();
        return;
      case "activate":
        currentVideoId = action.videoId;
        teardown();
        void activate(action.videoId).catch((error) => {
          console.error("[karaoke] activate failed", error);
        });
        return;
      case "reload": {
        generation += 1;
        const gen = generation;
        void load(action.videoId, gen).catch((error) => {
          console.error("[karaoke] reload failed", error);
        });
        return;
      }
    }
  }
  document.addEventListener("yt-navigate-finish", reconcile);
  setInterval(reconcile, NAVIGATION_POLL_MS);
  reconcile();
})();
